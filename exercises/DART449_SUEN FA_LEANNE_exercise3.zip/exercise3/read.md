Create a set of buttons that have the same class.
give them all the ability to increase points and to disappear when clicked.

Create another set of buttons that decrease points when clicked.

Display a message in a text element when the points reach 100 with the message "you win!".
