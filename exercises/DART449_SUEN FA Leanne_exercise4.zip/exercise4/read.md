Create a one page scrolling example.

Use the examples from today's my practice files to trigger animations when an element enters the viewport.

\*bonus: add other scroll based interactions from 02_scroll-examples-vanilla

\*\* double bonus: create a class for certain object that appear when entering the viewport. use querySelectorAll to give them the same eventListener
(something like when these elements are clicked, make something happen. point tracker or make other objects appear/disappear or change somehow)
